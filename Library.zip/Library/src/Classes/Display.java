
package Classes;


public interface Display {
    public void display();
}
